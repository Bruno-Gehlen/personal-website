--SIZES--
\tiny 
\scriptsize 	
\footnotesize
\small 	
\normalsize 	
\large 	
\Large 	
\LARGE 	
\huge 	
\Huge

--TITLESEC--
\titleformat{⟨command⟩}[⟨shape⟩]
    {⟨format⟩}
    {⟨label⟩}
    {⟨sep⟩}
    {⟨before-code⟩}[⟨after-code⟩]